package com.inception.crash_company_vendor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
