import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:image_picker/image_picker.dart';

class HomeDashbord extends StatefulWidget
{
  _HomeDashbord createState() => _HomeDashbord();
}

class _HomeDashbord extends State<HomeDashbord>
{
  int _selectedIndex = 1;
  List<Widget> _widgetOptions;

  File _image = null;
  final picker = ImagePicker();

  Future getImage() async {
    try{
      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
          _image = File(pickedFile.path);
        } else {
          print('No image selected.');
        }
      });
    }
    catch(e)
    {

      log(e);
    }
  }


  @override
  Widget build(BuildContext context) {
    _widgetOptions = <Widget>[
      Text('JOBS', style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold)),
      getHome(),
      getMapScreen()
    ];

    return Scaffold(
      backgroundColor: Colors.grey[200],
      bottomNavigationBar:BottomNavigationBar(
        fixedColor: Color.fromRGBO(0,0,102, 1),
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: (value) {
          // Respond to item press.
          setState(() => _selectedIndex = value);
        },
        items: [
          BottomNavigationBarItem(
            title: Text('NEW'),
            icon: Icon(Icons.mail),
          ),
          BottomNavigationBarItem(
            title: Text('DASHBORD'),
            icon: Icon(Icons.dashboard),
          ),
          BottomNavigationBarItem(
            title: Text('KC around you'),
            icon: Icon(Icons.map),
          ),
        ],
      ),


      body: Container(
       height: MediaQuery.of(context).size.height,
       width: MediaQuery.of(context).size.width,

       child: SafeArea(
         child: SingleChildScrollView(
           child: Column(
             children: [
               getCustomAppBar(),
               Center(
                 child: _widgetOptions.elementAt(_selectedIndex),
               ),
             ],
           ),
         ),
       ),
     ),

   );
  }

  Widget getHome()
  {
    return Column(
      children: [
        getFirstBanner(),
        getMenuBanners("Training Center","video about how to start with service"),
        getMenuBanners("Onboarding Documents","Pan, Address Proof, Documents for loan"),
        getMenuBanners("About me","Details about me"),
        getMenuBanners("Bank Details","Payout will be deposited in your account"),
        getContainerForPrice()
      ],
    );
  }


  Widget getCustomAppBar()
  {
    return Container(
      padding: EdgeInsets.all(10),
      width: MediaQuery.of(context).size.width,

      color: Colors.white,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
           height: 40,
           width: 40,
            decoration: BoxDecoration(

              shape: BoxShape.circle,
              border: Border.all(color: Color.fromRGBO(52, 73, 94, 1)),
            ),

            child: Icon(Icons.notifications,color: Color.fromRGBO(52, 73, 94, 1),size: 20,),

          ),


          SizedBox(width: 15,),
          Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Color.fromRGBO(52, 73, 94, 1)),
            ),
            child: Icon(Icons.menu,color: Color.fromRGBO(52, 73, 94, 1),size: 20,),
          ),
        ],
      ),
    );
  }

  Widget getFirstBanner()
  {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.all(10),
      width: MediaQuery.of(context).size.width,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Profile Progress",style: TextStyle(color: Color.fromRGBO(52, 73,94, 1),fontSize: 30,fontWeight: FontWeight.bold),),
                SizedBox(height: 10,),
                Text("Complete the below steps to",style: TextStyle(color: Color.fromRGBO(52, 73,94, 1),fontSize: 15),textAlign: TextAlign.start,),
                SizedBox(height: 5,),
                Text("Become a KC Partner",style: TextStyle(color: Color.fromRGBO(52, 73,94, 1),fontSize: 15),textAlign: TextAlign.start,)

              ],
            ),
          ),

          GestureDetector(
            onTap: getImage,
            child: Container(
              alignment: Alignment.centerRight,
              height: 80,
              width: 80,

              decoration: BoxDecoration(

                shape: BoxShape.circle,
                border: Border.all(color: Color.fromRGBO(52, 73, 94, 1))
              ),
              child: Center(
                child: _image == null ? Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.add),
                    Text("add photo",style: TextStyle(color: Color.fromRGBO(52, 73, 94, 1),fontSize: 15)) ,
                  ],
                ) : Container(height: 80,
                    width: 80,
                    margin:EdgeInsets.all(10),decoration: BoxDecoration(image: DecorationImage(image: FileImage(_image),fit: BoxFit.contain)) ),
              ),
            ),
          ),
        ],


      ),
    );
  }

  Widget getMenuBanners(String s1,String s2)
  {
    return Container(
      color: Colors.white,
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Material(
            elevation: 6,
            borderRadius: BorderRadius.circular(10),
            child: Container(

              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                color: Colors.white,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.all(15),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s1,style: TextStyle(color: Color.fromRGBO(52, 73, 94, 1),fontSize: 20,fontWeight: FontWeight.bold),),
                          SizedBox(height: 5,),
                          Text(s2,style: TextStyle(color: Color.fromRGBO(52, 73, 94, 1),fontSize: 12),)

                        ],
                      ),
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(15),
                    child: Icon(Icons.navigate_next,size: 30,color: Color.fromRGBO(52, 73, 94, 1),),
                  ),

                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget getContainerForPrice()
  {
    return Column(

      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(

          padding: EdgeInsets.all(10),

          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(5)),

          ),

          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              Expanded(
                  child: Container(
                      child: RaisedButton(
                        padding: EdgeInsets.all(15),
                        elevation: 0,
                        onPressed: (){

                        },
                        child: Text(
                          "SUBMIT",
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white
                          ),
                        ),
                        color: Color.fromRGBO(70, 89, 108, 1),

                      )
                  )
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget getMapScreen()
  {
    return Column(
      children: [
        Container(
          color: Colors.white,
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.all(10),

          child: Text("KC Around You",style: TextStyle(color: Color.fromRGBO(52, 73, 94, 1),fontSize: 25,fontWeight: FontWeight.bold),),
        ),


        Container(

          color: Colors.white,
          margin: EdgeInsets.fromLTRB(10, 10, 10, 10),

          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.fromLTRB(15, 15, 15, 15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("New jobs around you",style: TextStyle(color: Colors.grey,fontSize: 20),),

              SizedBox(height: 15,),
              Row(
                children: [
                  Icon(Icons.shopping_bag,size: 20,color: Color.fromRGBO(52, 73, 94, 1)),
                  SizedBox(width: 10,),
                  Text("0 jobs",style: TextStyle(color: Color.fromRGBO(52, 73, 94, 1),fontSize: 18),),
                ],
              ),

              SizedBox(height: 15),

              Row(
                children: [
                  Icon(Icons.money,size: 20,color: Color.fromRGBO(52, 73, 94, 1)),
                  SizedBox(width: 10,),
                  Text("Worth ₹0",style: TextStyle(color: Color.fromRGBO(52, 73, 94, 1),fontSize: 18),),
                ],

              ),

              SizedBox(height: 15),

              Container(
                width: MediaQuery.of(context).size.width,
                color: Color.fromRGBO(52, 73, 94, 1),
                height: 1,
              ),

              SizedBox(height: 5),

              Text("Last updated at 4 pm",style: TextStyle(color: Colors.grey,fontSize: 12),),

              SizedBox(height: 5),




            ],
          ),
          

        ),

      ],
    );
  }
}